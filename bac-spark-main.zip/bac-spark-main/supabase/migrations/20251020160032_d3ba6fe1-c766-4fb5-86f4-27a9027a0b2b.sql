-- Table pour les flashcards créées par les utilisateurs
CREATE TABLE public.user_flashcards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  theme TEXT NOT NULL,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table pour les flashcards générées par l'IA
CREATE TABLE public.ia_flashcards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  theme TEXT NOT NULL,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  generated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table pour les résultats de quiz
CREATE TABLE public.user_quiz_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  theme TEXT NOT NULL,
  score INTEGER NOT NULL,
  questions_total INTEGER NOT NULL,
  correct_answers INTEGER NOT NULL,
  date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table pour les fiches personnelles
CREATE TABLE public.user_fiches (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  titre TEXT NOT NULL,
  contenu TEXT NOT NULL,
  tags TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.user_flashcards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ia_flashcards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_quiz_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_fiches ENABLE ROW LEVEL SECURITY;

-- RLS Policies pour user_flashcards
CREATE POLICY "Users can view their own flashcards"
ON public.user_flashcards FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own flashcards"
ON public.user_flashcards FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own flashcards"
ON public.user_flashcards FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own flashcards"
ON public.user_flashcards FOR DELETE
USING (auth.uid() = user_id);

-- RLS Policies pour ia_flashcards
CREATE POLICY "Users can view their own IA flashcards"
ON public.ia_flashcards FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own IA flashcards"
ON public.ia_flashcards FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own IA flashcards"
ON public.ia_flashcards FOR DELETE
USING (auth.uid() = user_id);

-- RLS Policies pour user_quiz_results
CREATE POLICY "Users can view their own quiz results"
ON public.user_quiz_results FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own quiz results"
ON public.user_quiz_results FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- RLS Policies pour user_fiches
CREATE POLICY "Users can view their own fiches"
ON public.user_fiches FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own fiches"
ON public.user_fiches FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own fiches"
ON public.user_fiches FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own fiches"
ON public.user_fiches FOR DELETE
USING (auth.uid() = user_id);

-- Trigger pour updated_at sur user_fiches
CREATE TRIGGER update_user_fiches_updated_at
BEFORE UPDATE ON public.user_fiches
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();