-- Create a function to assign roles (security definer allows it to bypass RLS)
CREATE OR REPLACE FUNCTION public.assign_user_role(_user_id uuid, _role app_role)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role)
  VALUES (_user_id, _role)
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.assign_user_role TO authenticated;

-- Create RLS policy to allow inserting roles via the function
CREATE POLICY "Users can insert roles via function"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (true);