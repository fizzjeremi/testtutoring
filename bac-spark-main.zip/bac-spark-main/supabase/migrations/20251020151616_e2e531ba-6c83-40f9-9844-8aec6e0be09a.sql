-- Create user_metrics table
CREATE TABLE public.user_metrics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  sessions_this_week INTEGER DEFAULT 0,
  weekly_goal INTEGER DEFAULT 3,
  total_sessions INTEGER DEFAULT 0,
  today_study_minutes INTEGER DEFAULT 0,
  week_study_minutes INTEGER DEFAULT 0,
  current_focus TEXT,
  focus_progress INTEGER DEFAULT 0 CHECK (focus_progress >= 0 AND focus_progress <= 100),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on user_metrics
ALTER TABLE public.user_metrics ENABLE ROW LEVEL SECURITY;

-- Users can view their own metrics
CREATE POLICY "Users can view their own metrics" 
ON public.user_metrics 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can update their own metrics
CREATE POLICY "Users can update their own metrics" 
ON public.user_metrics 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Users can insert their own metrics
CREATE POLICY "Users can insert their own metrics" 
ON public.user_metrics 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_user_metrics_updated_at
BEFORE UPDATE ON public.user_metrics
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- Create resources table
CREATE TABLE public.resources (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('methodologie', 'fiche', 'exercice', 'correction')),
  title TEXT NOT NULL,
  description TEXT,
  content TEXT,
  difficulty TEXT CHECK (difficulty IN ('debutant', 'moyen', 'avance')),
  duration_minutes INTEGER,
  tags TEXT[],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on resources
ALTER TABLE public.resources ENABLE ROW LEVEL SECURITY;

-- Public can view all resources
CREATE POLICY "Resources are viewable by everyone" 
ON public.resources 
FOR SELECT 
USING (true);

-- Create user_resources junction table
CREATE TABLE public.user_resources (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  resource_id UUID NOT NULL REFERENCES public.resources(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed')),
  progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  last_accessed TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on user_resources
ALTER TABLE public.user_resources ENABLE ROW LEVEL SECURITY;

-- Users can view their own resource progress
CREATE POLICY "Users can view their own resource progress" 
ON public.user_resources 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can create their own resource progress
CREATE POLICY "Users can create their own resource progress" 
ON public.user_resources 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Users can update their own resource progress
CREATE POLICY "Users can update their own resource progress" 
ON public.user_resources 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Add trigger for updated_at on resources
CREATE TRIGGER update_resources_updated_at
BEFORE UPDATE ON public.resources
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- Create function to initialize user metrics
CREATE OR REPLACE FUNCTION public.initialize_user_metrics()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_metrics (user_id, streak, sessions_this_week, weekly_goal, current_focus)
  VALUES (NEW.user_id, 0, 0, 3, 'Découvrir la plateforme')
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Create trigger to initialize metrics when profile is created
CREATE TRIGGER initialize_metrics_on_profile_creation
AFTER INSERT ON public.user_profiles
FOR EACH ROW
EXECUTE FUNCTION public.initialize_user_metrics();