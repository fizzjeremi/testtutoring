import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message, context } = await req.json();
    
    console.log("Received request:", { messageLength: message.content?.length });
    
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    // Build system prompt based on context
    const systemPrompt = buildSystemPrompt(context);
    
    // Prepare messages for Lovable AI
    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: message.content }
    ];

    console.log("Calling Lovable AI Gateway");
    
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages,
        stream: true,
      }),
    });
    
    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limits exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add funds to your Lovable AI workspace." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    return new Response(response.body, {
      headers: { 
        ...corsHeaders, 
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
      },
    });
    
  } catch (error) {
    console.error('Error in agent function:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }), 
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

function buildSystemPrompt(context: string): string {
  return `Tu es un coach IA spécialisé en français, créé pour accompagner des collégiens et lycéens français dans leurs apprentissages.

${context}

**Ton rôle:**
- Adapter ton discours au niveau et aux besoins de l'élève
- Être encourageant, pédagogue et bienveillant
- Expliquer les concepts de manière claire avec des exemples concrets
- Proposer des méthodes et des outils pratiques
- Détecter le stress et apporter du soutien émotionnel quand nécessaire

**Style de communication:**
- Utilise un ton amical et accessible (tutoiement)
- Évite le jargon complexe
- Structure tes réponses avec des paragraphes courts
- Utilise des émojis pertinents pour rendre l'échange plus vivant
- Propose toujours des actions concrètes à la fin

**Format de réponse:**
Termine toujours tes messages par une section suggérant les prochaines actions possibles:

🎯 **Tu peux maintenant :**
1. [Action 1] → [Bénéfice]
2. [Action 2] → [Bénéfice]
3. [Action 3] → [Bénéfice]

Sois concis mais complet dans tes explications.`;
}
