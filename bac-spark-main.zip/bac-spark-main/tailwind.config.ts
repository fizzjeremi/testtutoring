import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./pages/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}"],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        'tl-blue': {
          DEFAULT: "hsl(var(--tl-blue))",
          light: "hsl(var(--tl-blue-light))",
          lighter: "hsl(var(--tl-blue-lighter))",
        },
        'tl-red': {
          DEFAULT: "hsl(var(--tl-red))",
          light: "hsl(var(--tl-red-light))",
          lighter: "hsl(var(--tl-red-lighter))",
        },
        blue: {
          DEFAULT: "hsl(var(--blue))",
          50: "hsl(var(--blue-50))",
          100: "hsl(var(--blue-100))",
          400: "hsl(var(--blue-400))",
          600: "hsl(var(--blue-600))",
        },
        sky: {
          DEFAULT: "hsl(var(--sky))",
          50: "hsl(var(--sky-50))",
          100: "hsl(var(--sky-100))",
          400: "hsl(var(--sky-400))",
          600: "hsl(var(--sky-600))",
        },
        indigo: {
          DEFAULT: "hsl(var(--indigo))",
          50: "hsl(var(--indigo-50))",
          100: "hsl(var(--indigo-100))",
          400: "hsl(var(--indigo-400))",
          600: "hsl(var(--indigo-600))",
        },
        emerald: {
          DEFAULT: "hsl(var(--emerald))",
          50: "hsl(var(--emerald-50))",
          100: "hsl(var(--emerald-100))",
          400: "hsl(var(--emerald-400))",
          600: "hsl(var(--emerald-600))",
        },
        amber: {
          DEFAULT: "hsl(var(--amber))",
          50: "hsl(var(--amber-50))",
          100: "hsl(var(--amber-100))",
          400: "hsl(var(--amber-400))",
          600: "hsl(var(--amber-600))",
          900: "hsl(var(--amber-900))",
        },
        rose: {
          DEFAULT: "hsl(var(--rose))",
          50: "hsl(var(--rose-50))",
          100: "hsl(var(--rose-100))",
          400: "hsl(var(--rose-400))",
          600: "hsl(var(--rose-600))",
        },
        gray: {
          50: "hsl(var(--gray-50))",
          200: "hsl(var(--gray-200))",
          600: "hsl(var(--gray-600))",
          700: "hsl(var(--gray-700))",
          900: "hsl(var(--gray-900))",
        },
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
