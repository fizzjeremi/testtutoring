import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";

interface InvoiceGeneratorProps {
  onGenerated?: () => void;
}

const InvoiceGenerator = ({ onGenerated }: InvoiceGeneratorProps) => {
  const [open, setOpen] = useState(false);
  const [parentId, setParentId] = useState("");
  const [startPeriod, setStartPeriod] = useState("");
  const [endPeriod, setEndPeriod] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!parentId || !startPeriod || !endPeriod) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);

      // Get lessons for the period
      const { data: lessons, error: lessonsError } = await supabase
        .from('lessons')
        .select(`
          *,
          student:students!lessons_student_id_fkey(
            parent_id,
            user_profiles!students_user_id_fkey(first_name)
          ),
          teacher:teachers!lessons_teacher_id_fkey(
            hourly_rate
          )
        `)
        .gte('start_at', new Date(startPeriod).toISOString())
        .lte('start_at', new Date(endPeriod).toISOString())
        .eq('status', 'completed');

      if (lessonsError) throw lessonsError;

      // Filter lessons by parent
      const parentLessons = lessons?.filter(l => l.student?.parent_id === parentId) || [];

      if (parentLessons.length === 0) {
        toast({
          title: "Aucun cours",
          description: "Aucun cours terminé trouvé pour cette période",
          variant: "destructive",
        });
        return;
      }

      // Calculate total amount
      const totalAmount = parentLessons.reduce((sum, lesson) => {
        const duration = (new Date(lesson.end_at).getTime() - new Date(lesson.start_at).getTime()) / (1000 * 60 * 60);
        const rate = lesson.teacher?.hourly_rate || 50;
        return sum + (duration * rate);
      }, 0);

      // Generate invoice number
      const invoiceNumber = `INV-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;

      // Create invoice
      const { data: invoice, error: invoiceError } = await supabase
        .from('invoices')
        .insert({
          parent_id: parentId,
          invoice_number: invoiceNumber,
          start_period: startPeriod,
          end_period: endPeriod,
          amount: totalAmount,
          status: 'draft',
        })
        .select()
        .single();

      if (invoiceError) throw invoiceError;

      // Create invoice items
      const items = parentLessons.map(lesson => {
        const duration = (new Date(lesson.end_at).getTime() - new Date(lesson.start_at).getTime()) / (1000 * 60 * 60);
        const rate = lesson.teacher?.hourly_rate || 50;
        return {
          invoice_id: invoice.id,
          lesson_id: lesson.id,
          description: `Cours de ${lesson.subject} - ${new Date(lesson.start_at).toLocaleDateString('fr-FR')}`,
          unit_price: rate,
          quantity: duration,
          total: duration * rate,
        };
      });

      const { error: itemsError } = await supabase
        .from('invoice_items')
        .insert(items);

      if (itemsError) throw itemsError;

      toast({
        title: "Facture générée",
        description: `Facture ${invoiceNumber} créée avec succès`,
      });

      setOpen(false);
      onGenerated?.();
    } catch (error) {
      console.error('Error generating invoice:', error);
      toast({
        title: "Erreur",
        description: "Impossible de générer la facture",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-[#1F2A74] hover:bg-[#1F2A74]/90">
          <Plus className="w-4 h-4 mr-2" />
          Générer une facture
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Générer une facture</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>ID Parent</Label>
            <Input
              value={parentId}
              onChange={(e) => setParentId(e.target.value)}
              placeholder="UUID du parent"
            />
          </div>

          <div>
            <Label>Date de début</Label>
            <Input
              type="date"
              value={startPeriod}
              onChange={(e) => setStartPeriod(e.target.value)}
            />
          </div>

          <div>
            <Label>Date de fin</Label>
            <Input
              type="date"
              value={endPeriod}
              onChange={(e) => setEndPeriod(e.target.value)}
            />
          </div>

          <Button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full bg-[#1F2A74]"
          >
            {loading ? "Génération..." : "Générer"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InvoiceGenerator;
