import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Download, Eye } from "lucide-react";

interface Invoice {
  id: string;
  invoice_number: string;
  start_period: string;
  end_period: string;
  amount: number;
  status: string;
  pdf_url: string | null;
  created_at: string;
}

interface InvoiceCardProps {
  invoice: Invoice;
  onDownload?: (id: string) => void;
}

const InvoiceCard = ({ invoice, onDownload }: InvoiceCardProps) => {
  const getStatusBadge = () => {
    const styles = {
      draft: "bg-gray-100 text-gray-800",
      sent: "bg-blue-100 text-blue-800",
      paid: "bg-green-100 text-green-800",
    };

    const labels = {
      draft: "Brouillon",
      sent: "Envoyée",
      paid: "Payée",
    };

    return (
      <Badge className={styles[invoice.status as keyof typeof styles]}>
        {labels[invoice.status as keyof typeof labels]}
      </Badge>
    );
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="font-bold text-lg">Facture {invoice.invoice_number}</h3>
              {getStatusBadge()}
            </div>
            
            <div className="space-y-1 text-sm text-gray-600">
              <p>
                Période : {format(new Date(invoice.start_period), "d MMM", { locale: fr })} - {format(new Date(invoice.end_period), "d MMM yyyy", { locale: fr })}
              </p>
              <p className="text-2xl font-bold text-[#1F2A74] mt-2">
                {invoice.amount.toFixed(2)} €
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            {invoice.pdf_url && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(invoice.pdf_url!, '_blank')}
                >
                  <Eye className="w-4 h-4 mr-1" />
                  Voir
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDownload?.(invoice.id)}
                >
                  <Download className="w-4 h-4 mr-1" />
                  Télécharger
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InvoiceCard;
