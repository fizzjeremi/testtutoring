import { BookOpen, FileText, Target, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <div className="bg-gradient-to-br from-violet via-fuchsia to-violet rounded-3xl p-12 text-white relative overflow-hidden">
      {/* Decoration blobs */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>

      {/* Content */}
      <div className="relative z-10">
        <h2 className="text-4xl md:text-5xl font-black mb-4 text-center">
          Tout ce dont tu as besoin pour réussir le Bac Français
        </h2>
        <p className="text-xl text-white/90 text-center mb-8 max-w-3xl mx-auto">
          Méthodologies, fiches, exercices, corrections personnalisées et coach IA
        </p>

        {/* CTAs */}
        <div className="flex justify-center gap-4 mb-12">
          <Button 
            size="lg"
            className="bg-white text-gray-900 rounded-2xl px-8 py-6 text-lg font-bold hover:bg-white/90"
          >
            Explorer la Bibliothèque
          </Button>
          <Button 
            size="lg"
            variant="outline"
            className="border-2 border-white text-white rounded-2xl px-8 py-6 text-lg font-bold hover:bg-white/10"
          >
            Voir la démo
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-4 gap-6">
          {/* Feature 1 */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
            <div className="w-16 h-16 bg-violet-400/40 rounded-2xl flex items-center justify-center mb-4">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-black mb-2">Méthodologies</h3>
            <p className="text-white/80 text-sm">
              Dissertation, commentaire, oral : toutes les méthodes expliquées pas à pas
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
            <div className="w-16 h-16 bg-cyan-400/40 rounded-2xl flex items-center justify-center mb-4">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-black mb-2">Fiches Méthode</h3>
            <p className="text-white/80 text-sm">
              Fiches de révision générées par l'IA, personnalisées à ton niveau
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
            <div className="w-16 h-16 bg-cyan-400/40 rounded-2xl flex items-center justify-center mb-4">
              <Target className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-black mb-2">Entraînements</h3>
            <p className="text-white/80 text-sm">
              Quiz, exercices progressifs, simulations d'oral pour t'entraîner
            </p>
          </div>

          {/* Feature 4 */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
            <div className="w-16 h-16 bg-pink-400/40 rounded-2xl flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-black mb-2">Corrections IA</h3>
            <p className="text-white/80 text-sm">
              Feedback personnalisé sur tes dissertations et commentaires
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
