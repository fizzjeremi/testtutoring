import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const MindMapPreview = () => {
  const navigate = useNavigate();
  
  return (
    <div className="sticky top-24 bg-gradient-to-br from-violet to-fuchsia rounded-3xl p-6 text-white shadow-lg">
      <h3 className="text-xl font-black mb-2">Ta carte mentale</h3>
      <p className="text-white/90 text-sm mb-4">Visualise tes connaissances</p>
      
      {/* Miniature interactive */}
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 mb-4 min-h-[200px] relative overflow-hidden">
        {/* Nodes simulés */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="w-16 h-16 bg-white/30 rounded-full flex items-center justify-center text-xs font-bold">
            Centre
          </div>
        </div>
        
        {/* Nodes périphériques */}
        <div className="absolute top-8 left-8 w-12 h-12 bg-green-400/40 rounded-full"></div>
        <div className="absolute top-8 right-8 w-12 h-12 bg-orange-400/40 rounded-full"></div>
        <div className="absolute bottom-8 left-12 w-12 h-12 bg-green-400/40 rounded-full"></div>
        <div className="absolute bottom-8 right-12 w-12 h-12 bg-red-400/40 rounded-full"></div>
        
        {/* Connexions */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <line x1="50%" y1="50%" x2="20%" y2="20%" stroke="white" strokeOpacity="0.2" strokeWidth="2" />
          <line x1="50%" y1="50%" x2="80%" y2="20%" stroke="white" strokeOpacity="0.2" strokeWidth="2" />
          <line x1="50%" y1="50%" x2="25%" y2="80%" stroke="white" strokeOpacity="0.2" strokeWidth="2" />
          <line x1="50%" y1="50%" x2="75%" y2="80%" stroke="white" strokeOpacity="0.2" strokeWidth="2" />
        </svg>
      </div>

      {/* Stats rapides */}
      <div className="grid grid-cols-3 gap-2 mb-4 text-center">
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2">
          <div className="text-2xl font-black">12</div>
          <div className="text-xs text-white/80">Maîtrisés</div>
        </div>
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2">
          <div className="text-2xl font-black">8</div>
          <div className="text-xs text-white/80">En cours</div>
        </div>
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2">
          <div className="text-2xl font-black">5</div>
          <div className="text-xs text-white/80">À réviser</div>
        </div>
      </div>

      <Button 
        className="w-full bg-white text-violet-600 rounded-2xl font-bold hover:bg-white/90"
        onClick={() => navigate("/cartes-mentales")}
      >
        Gérer mes cartes mentales
      </Button>
    </div>
  );
};

export default MindMapPreview;
