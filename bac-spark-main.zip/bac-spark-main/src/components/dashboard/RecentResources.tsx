import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FileText, Target, Edit, BookOpen, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

interface Resource {
  id: string;
  type: "methodologie" | "fiche" | "exercice" | "correction";
  title: string;
  description: string;
  status: "not_started" | "in_progress" | "completed";
  progress: number;
  lastAccessed: Date;
}

const RecentResources = () => {
  const [activeTab, setActiveTab] = useState("all");
  const navigate = useNavigate();

  // Mock data - remplacer par vraies données Supabase
  const resources: Resource[] = [
    {
      id: "1",
      type: "fiche",
      title: "Méthodologie de la dissertation",
      description: "Les 5 étapes essentielles pour réussir",
      status: "in_progress",
      progress: 67,
      lastAccessed: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2h ago
    },
    {
      id: "2",
      type: "exercice",
      title: "Quiz sur les figures de style",
      description: "15 questions pour tester vos connaissances",
      status: "completed",
      progress: 100,
      lastAccessed: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    },
    {
      id: "3",
      type: "methodologie",
      title: "Le commentaire composé",
      description: "Analyse méthodique d'un texte littéraire",
      status: "not_started",
      progress: 0,
      lastAccessed: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    },
  ];

  const getTypeIcon = (type: Resource["type"]) => {
    switch (type) {
      case "fiche":
        return <FileText className="w-5 h-5" />;
      case "exercice":
        return <Target className="w-5 h-5" />;
      case "correction":
        return <Edit className="w-5 h-5" />;
      case "methodologie":
        return <BookOpen className="w-5 h-5" />;
    }
  };

  const getTypeColor = (type: Resource["type"]) => {
    switch (type) {
      case "fiche":
        return "bg-violet-100 text-violet-600";
      case "exercice":
        return "bg-cyan-100 text-cyan-600";
      case "correction":
        return "bg-amber-100 text-amber-600";
      case "methodologie":
        return "bg-green-100 text-green-600";
    }
  };

  const getStatusBadge = (status: Resource["status"]) => {
    switch (status) {
      case "in_progress":
        return <Badge variant="secondary">En cours</Badge>;
      case "completed":
        return <Badge className="bg-green-100 text-green-700 hover:bg-green-100">Terminé</Badge>;
      case "not_started":
        return <Badge variant="outline">À réviser</Badge>;
    }
  };

  const getTimeAgo = (date: Date) => {
    const hours = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60));
    if (hours < 1) return "Il y a moins d'1h";
    if (hours < 24) return `Il y a ${hours}h`;
    const days = Math.floor(hours / 24);
    return `Il y a ${days}j`;
  };

  return (
    <div>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-4">
        <TabsList className="bg-muted">
          <TabsTrigger value="all">Tout</TabsTrigger>
          <TabsTrigger value="fiche">Fiches</TabsTrigger>
          <TabsTrigger value="exercice">Exercices</TabsTrigger>
          <TabsTrigger value="correction">Corrections</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="space-y-3">
        {resources.map((resource) => (
          <div
            key={resource.id}
            className="bg-card border-2 border-gray-200 rounded-2xl p-4 hover:border-gray-900 transition-all cursor-pointer"
          >
            <div className="flex items-start gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${getTypeColor(resource.type)}`}>
                {getTypeIcon(resource.type)}
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-1">
                  <h3 className="font-bold text-gray-900">{resource.title}</h3>
                  <ExternalLink className="w-4 h-4 text-gray-400" />
                </div>
                <p className="text-sm text-gray-600 mb-2">{resource.description}</p>
                <div className="flex items-center gap-3 text-sm text-gray-500">
                  {getStatusBadge(resource.status)}
                  <span>•</span>
                  <span>{getTimeAgo(resource.lastAccessed)}</span>
                  {resource.progress > 0 && (
                    <>
                      <span>•</span>
                      <span>{resource.progress}% complété</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 text-center">
        <Button 
          variant="outline" 
          className="border-2 border-gray-900 rounded-full font-bold"
          onClick={() => navigate("/bibliotheque")}
        >
          Voir toutes les ressources
        </Button>
      </div>
    </div>
  );
};

export default RecentResources;
