import { useNavigate } from "react-router-dom";
import { Flame, Target, Sparkles, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

interface StatsCardsProps {
  streak: number;
  longestStreak: number;
  sessionsThisWeek: number;
  weeklyGoal: number;
  currentFocus: string | null;
  focusProgress: number;
}

const StatsCards = ({ 
  streak, 
  longestStreak,
  sessionsThisWeek, 
  weeklyGoal, 
  currentFocus, 
  focusProgress 
}: StatsCardsProps) => {
  const navigate = useNavigate();
  
  const getStreakBadge = () => {
    if (streak >= 30) return { text: "Champion !", emoji: "🏆" };
    if (streak >= 14) return { text: "Diamant", emoji: "💎" };
    if (streak >= 7) return { text: "Une semaine !", emoji: "⭐" };
    if (streak >= 3) return { text: "En feu !", emoji: "🔥" };
    return null;
  };

  const badge = getStreakBadge();

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-black text-gray-900">Tes statistiques</h2>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate("/progres")}
            className="border-2 border-gray-900 gap-2 font-bold"
          >
            <TrendingUp className="w-4 h-4" />
            Voir les détails
          </Button>
      </div>
      
      <div className="grid md:grid-cols-3 gap-4">
      {/* Streak Card */}
      <div className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-400 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <Flame className="w-6 h-6 text-orange-600" />
          <span className="font-bold text-gray-700">Jours consécutifs</span>
        </div>
        <div className="text-3xl font-black text-orange-600 mb-2">
          {streak} jour{streak > 1 ? "s" : ""}
        </div>
        <div className="text-sm text-gray-600">
          {badge ? (
            <span className="font-bold">
              {badge.emoji} {badge.text}
            </span>
          ) : (
            <>Record: {longestStreak} jour{longestStreak > 1 ? "s" : ""}</>
          )}
        </div>
      </div>

      {/* Sessions Card */}
      <div className="bg-gradient-to-br from-cyan-50 to-cyan-100 border-2 border-cyan-400 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <Target className="w-6 h-6 text-cyan-600" />
          <span className="font-bold text-gray-700">Sessions hebdomadaires</span>
        </div>
        <div className="text-3xl font-black text-cyan-600 mb-2">
          {sessionsThisWeek}/{weeklyGoal}
        </div>
        <div className="w-full bg-cyan-200 rounded-full h-2 mb-1">
          <div 
            className="bg-cyan-600 h-2 rounded-full transition-all duration-500"
            style={{ width: `${Math.min((sessionsThisWeek / weeklyGoal) * 100, 100)}%` }}
          ></div>
        </div>
        <div className="text-sm text-gray-600">
          {weeklyGoal - sessionsThisWeek > 0 
            ? `${weeklyGoal - sessionsThisWeek} session${weeklyGoal - sessionsThisWeek > 1 ? "s" : ""} restante${weeklyGoal - sessionsThisWeek > 1 ? "s" : ""}`
            : "Objectif atteint ! 🎉"
          }
        </div>
      </div>

      {/* Focus Card */}
      <div className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-400 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="w-6 h-6 text-purple-600" />
          <span className="font-bold text-gray-700">Focus actuel</span>
        </div>
        <div className="text-xl font-black text-purple-600 mb-2 line-clamp-2">
          {currentFocus || "Aucun focus défini"}
        </div>
        <div className="w-full bg-purple-200 rounded-full h-2 mb-1">
          <div 
            className="bg-purple-600 h-2 rounded-full transition-all duration-500"
            style={{ width: `${focusProgress}%` }}
          ></div>
        </div>
        <div className="text-sm text-gray-600">
          {focusProgress}% maîtrisé
        </div>
      </div>
      </div>
    </div>
  );
};

export default StatsCards;
