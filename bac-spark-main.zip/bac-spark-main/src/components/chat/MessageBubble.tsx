import { format } from "date-fns";
import { fr } from "date-fns/locale";

interface MessageBubbleProps {
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  mode?: string;
}

const MessageBubble = ({ role, content, timestamp, mode }: MessageBubbleProps) => {
  const isUser = role === "user";
  
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-[80%] ${isUser ? "ml-12" : "mr-12"}`}>
        <div
          className={`rounded-2xl px-4 py-3 ${
            isUser
              ? "bg-violet-600 text-white"
              : "bg-white text-gray-900 border-2 border-gray-200"
          }`}
        >
          <div className="whitespace-pre-wrap break-words">{content}</div>
        </div>
        <div className={`text-xs text-gray-500 mt-1 ${isUser ? "text-right" : "text-left"}`}>
          {format(timestamp, "HH:mm", { locale: fr })}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
