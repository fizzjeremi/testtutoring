import { Button } from "@/components/ui/button";

interface SuggestionButtonsProps {
  suggestions: string[];
  onSelect: (suggestion: string) => void;
}

const SuggestionButtons = ({ suggestions, onSelect }: SuggestionButtonsProps) => {
  return (
    <div className="flex flex-wrap gap-2">
      {suggestions.map((suggestion, index) => (
        <Button
          key={index}
          variant="outline"
          onClick={() => onSelect(suggestion)}
          className="rounded-full text-sm border-2 border-gray-900 hover:bg-violet-50"
        >
          {suggestion}
        </Button>
      ))}
    </div>
  );
};

export default SuggestionButtons;
