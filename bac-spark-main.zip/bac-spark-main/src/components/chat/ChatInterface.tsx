import { useState, useRef, useEffect } from "react";
import { agentClient } from "@/lib/agent-client";
import { ModeDetector } from "@/lib/ModeDetector";
import { supabase } from "@/integrations/supabase/client";
import MessageBubble from "./MessageBubble";
import SuggestionButtons from "./SuggestionButtons";
import ModeIndicator from "./ModeIndicator";
import TypingIndicator from "./TypingIndicator";
import ConversationHistory from "./ConversationHistory";
import { ChevronDown, Send, Plus, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  mode?: string;
  suggestions?: string[];
}

interface ChatInterfaceProps {
  userProfile?: {
    first_name: string;
    current_level: string | null;
    main_challenge: string | null;
  };
  initialMode?: string;
  revisionSuggestions?: string[];
}

const ChatInterface = ({ userProfile, initialMode = "explicatif", revisionSuggestions }: ChatInterfaceProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [currentMode, setCurrentMode] = useState<string>(initialMode);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  
  const { toast } = useToast();
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const streamingContentRef = useRef("");
  const shouldAutoSaveRef = useRef(true);
  
  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
    
    setShowScrollButton(!isNearBottom);
  };
  
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
      return () => container.removeEventListener("scroll", handleScroll);
    }
  }, []);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  const [shouldAutoScroll, setShouldAutoScroll] = useState(false);
  
  useEffect(() => {
    if (shouldAutoScroll) {
      scrollToBottom();
      setShouldAutoScroll(false);
    }
  }, [messages, shouldAutoScroll]);
  
  // Sauvegarder automatiquement la conversation
  useEffect(() => {
    if (messages.length > 0 && currentConversationId && shouldAutoSaveRef.current) {
      saveConversation();
    }
  }, [messages, currentConversationId]);
  
  const createNewConversation = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('conversations')
        .insert({
          user_id: user.id,
          title: "Nouvelle discussion"
        })
        .select()
        .single();

      if (error) throw error;

      setCurrentConversationId(data.id);
      setMessages([]);
      
      toast({
        title: "Nouvelle discussion",
        description: "Discussion créée avec succès",
      });
    } catch (error) {
      console.error('Error creating conversation:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer une nouvelle discussion",
        variant: "destructive",
      });
    }
  };
  
  const loadConversation = async (conversationId: string) => {
    try {
      shouldAutoSaveRef.current = false;
      
      const { data, error } = await supabase
        .from('conversation_messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('timestamp', { ascending: true });

      if (error) throw error;

      const loadedMessages: Message[] = data.map(msg => ({
        role: msg.role as "user" | "assistant",
        content: msg.content,
        timestamp: msg.timestamp,
        mode: msg.mode || undefined,
        suggestions: undefined
      }));

      setMessages(loadedMessages);
      setCurrentConversationId(conversationId);
      
      setTimeout(() => {
        shouldAutoSaveRef.current = true;
      }, 500);
      
      toast({
        title: "Chargé",
        description: "Discussion chargée",
      });
    } catch (error) {
      console.error('Error loading conversation:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger la discussion",
        variant: "destructive",
      });
    }
  };
  
  const saveConversation = async () => {
    if (!currentConversationId || messages.length === 0) return;

    try {
      const title = messages[0]?.content.substring(0, 50) + 
                   (messages[0]?.content.length > 50 ? "..." : "");

      await supabase
        .from('conversations')
        .update({ 
          title,
          updated_at: new Date().toISOString()
        })
        .eq('id', currentConversationId);

      await supabase
        .from('conversation_messages')
        .delete()
        .eq('conversation_id', currentConversationId);

      const messagesToSave = messages.map(msg => ({
        conversation_id: currentConversationId,
        role: msg.role,
        content: msg.content,
        mode: msg.mode,
        timestamp: msg.timestamp
      }));

      if (messagesToSave.length > 0) {
        await supabase
          .from('conversation_messages')
          .insert(messagesToSave);
      }
    } catch (error) {
      console.error('Error saving conversation:', error);
    }
  };
  
  const sendMessage = async (messageText?: string) => {
    if (!currentConversationId) {
      await createNewConversation();
      await new Promise(resolve => setTimeout(resolve, 300));
    }
    
    const textToSend = messageText || input;
    if (!textToSend.trim() || isLoading) return;
    
    const userMessage: Message = {
      role: "user",
      content: textToSend,
      timestamp: Date.now()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    setShouldAutoScroll(true);
    
    const detectedMode = ModeDetector.detectMode(textToSend, currentMode as any);
    setCurrentMode(detectedMode);
    
    try {
      const context = {
        user_first_name: userProfile?.first_name || "",
        user_level: (userProfile?.current_level || "") as any,
        user_challenge: userProfile?.main_challenge || "",
        current_mode: detectedMode as any,
        conversation_history: messages.slice(-10),
        stress_level: "moyen" as const
      };
      
      const response = await agentClient.sendMessage(textToSend, context, true);
      
      streamingContentRef.current = "";
      const assistantMessage: Message = {
        role: "assistant",
        content: "",
        timestamp: Date.now(),
        mode: detectedMode
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      
      for await (const chunk of agentClient.streamResponse(response)) {
        streamingContentRef.current += chunk;
        
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          lastMessage.content = streamingContentRef.current;
          return newMessages;
        });
      }
      
      const suggestions = extractSuggestions(streamingContentRef.current);
      if (suggestions.length > 0) {
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          lastMessage.suggestions = suggestions;
          return newMessages;
        });
      }
      
    } catch (error) {
      console.error("Error sending message:", error);
      
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "Désolé, une erreur s'est produite. Peux-tu réessayer ?",
        timestamp: Date.now()
      }]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const extractSuggestions = (content: string): string[] => {
    const match = content.match(/🎯 \*\*Tu peux maintenant :\*\*\n([\s\S]*?)(?:\*\*|$)/);
    if (!match) return [];
    
    const suggestionsText = match[1];
    const suggestions = suggestionsText
      .split("\n")
      .filter(line => line.match(/^\d+\./))
      .map(line => line.replace(/^\d+\.\s*/, "").replace(/→.*$/, "").trim())
      .filter(Boolean);
    
    return suggestions;
  };
  
  return (
    <div className="border-2 border-gray-900 rounded-3xl overflow-hidden bg-white">
      <div className="bg-violet-100 border-b-2 border-gray-900 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-gray-900">Coach IA</h2>
            <p className="text-sm text-gray-600">Tuteur virtuel adaptatif</p>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={createNewConversation}
              className="gap-2 border-2 border-gray-900"
            >
              <Plus className="w-4 h-4" />
              Nouveau
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowHistory(true)}
              className="gap-2 border-2 border-gray-900"
            >
              <History className="w-4 h-4" />
              Historique
            </Button>
            
            <ModeIndicator mode={currentMode} />
          </div>
        </div>
      </div>
      
      <div 
        ref={scrollContainerRef}
        className="h-[500px] overflow-y-auto p-4 space-y-4 bg-gray-50 relative"
      >
        {messages.length === 0 && (
          <div className="text-center text-gray-500 py-12">
            <div className="text-6xl mb-4">👋</div>
            <h3 className="text-2xl font-bold mb-2">Bienvenue !</h3>
            <p className="mb-6">
              {initialMode === "revision" 
                ? "Je suis ton coach révision IA. Prêt à mémoriser et consolider tes connaissances ?"
                : "Je suis ton coach français IA. Comment puis-je t'aider aujourd'hui ?"}
            </p>
            <SuggestionButtons
              suggestions={revisionSuggestions || [
                "Explique-moi comment faire une dissertation",
                "Crée-moi une fiche méthode sur le commentaire",
                "Teste-moi sur les figures de style",
                "J'ai besoin de motivation pour réviser"
              ]}
              onSelect={sendMessage}
            />
          </div>
        )}
        
        {messages.map((message, index) => (
          <div key={index}>
            <MessageBubble
              role={message.role}
              content={message.content}
              timestamp={message.timestamp}
              mode={message.mode}
            />
            
            {message.suggestions && message.suggestions.length > 0 && (
              <div className="mt-2 ml-12">
                <SuggestionButtons
                  suggestions={message.suggestions}
                  onSelect={sendMessage}
                />
              </div>
            )}
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white rounded-2xl px-4 py-3 border-2 border-gray-200">
              <TypingIndicator />
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
        
        {showScrollButton && (
          <button
            onClick={scrollToBottom}
            className="fixed bottom-24 left-1/2 transform -translate-x-1/2 bg-white border-2 border-gray-900 rounded-full p-3 shadow-2xl hover:scale-105 transition-all z-10"
            aria-label="Retour en bas"
          >
            <ChevronDown className="w-5 h-5 text-gray-900" />
          </button>
        )}
      </div>
      
      <div className="bg-white border-t-2 border-gray-900 p-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Écris ton message..."
            className="flex-1 px-4 py-3 border-2 border-gray-900 rounded-full focus:outline-none focus:ring-2 focus:ring-violet-600"
            disabled={isLoading}
          />
          <Button
            onClick={() => sendMessage()}
            disabled={isLoading || !input.trim()}
            className="px-6 py-3 bg-gray-900 text-white rounded-full hover:bg-gray-800 font-bold"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
      
      <ConversationHistory
        open={showHistory}
        onOpenChange={setShowHistory}
        onSelectConversation={loadConversation}
        currentConversationId={currentConversationId}
      />
    </div>
  );
};

export default ChatInterface;
