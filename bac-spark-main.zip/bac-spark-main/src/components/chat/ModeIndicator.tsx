import { ModeDetector } from "@/lib/ModeDetector";
import { Badge } from "@/components/ui/badge";

interface ModeIndicatorProps {
  mode: string;
}

const ModeIndicator = ({ mode }: ModeIndicatorProps) => {
  return null;
};

export default ModeIndicator;
