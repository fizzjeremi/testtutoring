import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Calendar, 
  BookOpen, 
  FileText, 
  User,
  Settings,
  LogOut,
  Users
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { UserRole } from "@/hooks/useUserRole";

interface NavigationProps {
  role: UserRole;
}

const Navigation = ({ role }: NavigationProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Déconnexion réussie",
      description: "À bientôt !",
    });
    navigate("/login");
  };

  const navItems = {
    student: [
      { path: "/dashboard", icon: LayoutDashboard, label: "Tableau de bord" },
      { path: "/lessons", icon: Calendar, label: "Mes cours" },
      { path: "/bac", icon: BookOpen, label: "Bac Français" },
      { path: "/profile", icon: User, label: "Profil" },
    ],
    teacher: [
      { path: "/dashboard", icon: LayoutDashboard, label: "Tableau de bord" },
      { path: "/lessons", icon: Calendar, label: "Mes cours" },
      { path: "/availabilities", icon: Calendar, label: "Disponibilités" },
      { path: "/bac", icon: BookOpen, label: "Bac Français" },
      { path: "/profile", icon: User, label: "Profil" },
    ],
    parent: [
      { path: "/dashboard", icon: LayoutDashboard, label: "Tableau de bord" },
      { path: "/lessons", icon: Calendar, label: "Cours de mon enfant" },
      { path: "/invoices", icon: FileText, label: "Factures" },
      { path: "/profile", icon: User, label: "Profil" },
    ],
    super_admin: [
      { path: "/dashboard", icon: LayoutDashboard, label: "Tableau de bord" },
      { path: "/admin/users", icon: Users, label: "Utilisateurs" },
      { path: "/admin/lessons", icon: Calendar, label: "Tous les cours" },
      { path: "/admin/invoices", icon: FileText, label: "Facturation" },
      { path: "/admin/settings", icon: Settings, label: "Paramètres" },
    ],
  };

  const items = navItems[role] || navItems.student;

  return (
    <nav className="bg-white border-b-2 border-gray-900 w-full">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-black text-tl-blue">Tutoring London</h1>
          <span className="text-xs text-gray-600 font-medium capitalize px-2 py-1 bg-gray-100 rounded">
            {role.replace('_', ' ')}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {items.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <Link key={item.path} to={item.path}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  className={`font-semibold transition-all ${
                    isActive 
                      ? "bg-tl-blue text-white shadow-md" 
                      : "hover:bg-tl-blue-lighter"
                  }`}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
          
          <Button
            variant="ghost"
            size="sm"
            className="text-tl-red hover:text-tl-red hover:bg-tl-red-lighter font-semibold transition-all ml-4"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Déconnexion
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
