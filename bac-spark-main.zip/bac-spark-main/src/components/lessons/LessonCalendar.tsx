import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format, startOfWeek, addDays, addWeeks, subWeeks, isSameDay } from "date-fns";
import { fr } from "date-fns/locale";
import { ChevronLeft, ChevronRight, Video } from "lucide-react";

interface Lesson {
  id: string;
  subject: string;
  start_at: string;
  end_at: string;
  status: string;
  meeting_link: string | null;
  teacher_id: string;
  student_id: string;
}

interface LessonWithProfiles extends Lesson {
  teacher_name?: string;
  student_name?: string;
}

interface LessonCalendarProps {
  userRole: 'student' | 'teacher' | 'parent';
}

const LessonCalendar = ({ userRole }: LessonCalendarProps) => {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [lessons, setLessons] = useState<LessonWithProfiles[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadLessons();
  }, [currentWeek]);

  const loadLessons = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
      const weekEnd = addDays(weekStart, 7);

      let query = supabase
        .from('lessons')
        .select('*')
        .gte('start_at', weekStart.toISOString())
        .lt('start_at', weekEnd.toISOString())
        .order('start_at');

      const { data, error } = await query;

      if (error) throw error;
      setLessons(data || []);
    } catch (error) {
      console.error('Error loading lessons:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les cours",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getWeekDays = () => {
    const start = startOfWeek(currentWeek, { weekStartsOn: 1 });
    return Array.from({ length: 7 }, (_, i) => addDays(start, i));
  };

  const getLessonsForDay = (day: Date) => {
    return lessons.filter(lesson => 
      isSameDay(new Date(lesson.start_at), day)
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-800 border-green-200';
      case 'requested': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'canceled': return 'bg-red-100 text-red-800 border-red-200';
      case 'completed': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'confirmed': return 'Confirmé';
      case 'requested': return 'En attente';
      case 'canceled': return 'Annulé';
      case 'completed': return 'Terminé';
      default: return status;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Calendrier des cours</CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentWeek(subWeeks(currentWeek, 1))}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium min-w-[200px] text-center">
              {format(currentWeek, "MMMM yyyy", { locale: fr })}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-center py-8">
            <p className="text-gray-600">Chargement...</p>
          </div>
        ) : (
          <div className="grid grid-cols-7 gap-2">
            {getWeekDays().map((day, index) => {
              const dayLessons = getLessonsForDay(day);
              const isToday = isSameDay(day, new Date());

              return (
                <div
                  key={index}
                  className={`border rounded-lg p-2 min-h-[120px] ${
                    isToday ? 'bg-blue-50 border-[#1F2A74]' : 'bg-white'
                  }`}
                >
                  <div className="text-xs font-semibold text-gray-600 mb-2">
                    {format(day, "EEE d", { locale: fr })}
                  </div>
                  <div className="space-y-1">
                    {dayLessons.map((lesson) => (
                      <div
                        key={lesson.id}
                        className={`text-xs p-2 rounded border ${getStatusColor(lesson.status)}`}
                      >
                        <div className="font-semibold truncate">{lesson.subject}</div>
                        <div className="text-xs">
                          {format(new Date(lesson.start_at), "HH:mm")}
                        </div>
                        {lesson.meeting_link && lesson.status === 'confirmed' && (
                          <a
                            href={lesson.meeting_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 mt-1 text-[#1F2A74] hover:underline"
                          >
                            <Video className="w-3 h-3" />
                            <span>Rejoindre</span>
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default LessonCalendar;
