import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Clock, User, Video, CheckCircle, XCircle } from "lucide-react";
import { useUserRole } from "@/hooks/useUserRole";

interface Lesson {
  id: string;
  subject: string;
  start_at: string;
  end_at: string;
  status: string;
  meeting_link: string | null;
  notes_teacher: string | null;
  notes_student: string | null;
  teacher_id: string;
  student_id: string;
}

interface LessonWithProfiles extends Lesson {
  teacher_name?: string;
  student_name?: string;
}

const LessonsList = () => {
  const [lessons, setLessons] = useState<LessonWithProfiles[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'past'>('upcoming');
  const { role } = useUserRole();
  const { toast } = useToast();

  useEffect(() => {
    loadLessons();
  }, [filter]);

  const loadLessons = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      let query = supabase
        .from('lessons')
        .select('*')
        .order('start_at', { ascending: filter === 'past' ? false : true });

      if (filter === 'upcoming') {
        query = query.gte('start_at', new Date().toISOString());
      } else if (filter === 'past') {
        query = query.lt('start_at', new Date().toISOString());
      }

      const { data: lessonsData, error } = await query;

      if (error) throw error;

      // Load teacher and student profiles
      if (lessonsData && lessonsData.length > 0) {
        const teacherIds = [...new Set(lessonsData.map(l => l.teacher_id))];
        const studentIds = [...new Set(lessonsData.map(l => l.student_id))];

        const { data: teacherProfiles } = await supabase
          .from('teachers')
          .select('id, user_id')
          .in('id', teacherIds);

        const { data: studentProfiles } = await supabase
          .from('students')
          .select('id, user_id')
          .in('id', studentIds);

        const teacherUserIds = teacherProfiles?.map(t => t.user_id) || [];
        const studentUserIds = studentProfiles?.map(s => s.user_id) || [];

        const { data: userProfiles } = await supabase
          .from('user_profiles')
          .select('user_id, first_name')
          .in('user_id', [...teacherUserIds, ...studentUserIds]);

        const lessonsWithNames = lessonsData.map(lesson => {
          const teacher = teacherProfiles?.find(t => t.id === lesson.teacher_id);
          const student = studentProfiles?.find(s => s.id === lesson.student_id);
          const teacherProfile = userProfiles?.find(p => p.user_id === teacher?.user_id);
          const studentProfile = userProfiles?.find(p => p.user_id === student?.user_id);

          return {
            ...lesson,
            teacher_name: teacherProfile?.first_name,
            student_name: studentProfile?.first_name,
          };
        });

        setLessons(lessonsWithNames);
      } else {
        setLessons([]);
      }
    } catch (error) {
      console.error('Error loading lessons:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les cours",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = async (lessonId: string) => {
    try {
      const { error } = await supabase
        .from('lessons')
        .update({ status: 'confirmed' })
        .eq('id', lessonId);

      if (error) throw error;

      toast({
        title: "Cours confirmé",
        description: "Le cours a été confirmé avec succès",
      });

      loadLessons();
    } catch (error) {
      console.error('Error confirming lesson:', error);
      toast({
        title: "Erreur",
        description: "Impossible de confirmer le cours",
        variant: "destructive",
      });
    }
  };

  const handleCancel = async (lessonId: string) => {
    try {
      const { error } = await supabase
        .from('lessons')
        .update({ status: 'canceled' })
        .eq('id', lessonId);

      if (error) throw error;

      toast({
        title: "Cours annulé",
        description: "Le cours a été annulé",
      });

      loadLessons();
    } catch (error) {
      console.error('Error canceling lesson:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'annuler le cours",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      confirmed: "bg-green-100 text-green-800",
      requested: "bg-yellow-100 text-yellow-800",
      canceled: "bg-red-100 text-red-800",
      completed: "bg-gray-100 text-gray-800",
    };

    const labels = {
      confirmed: "Confirmé",
      requested: "En attente",
      canceled: "Annulé",
      completed: "Terminé",
    };

    return (
      <Badge className={styles[status as keyof typeof styles] || styles.completed}>
        {labels[status as keyof typeof labels] || status}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Mes cours</CardTitle>
          <div className="flex gap-2">
            <Button
              variant={filter === 'upcoming' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('upcoming')}
            >
              À venir
            </Button>
            <Button
              variant={filter === 'past' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('past')}
            >
              Passés
            </Button>
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              Tous
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-center py-8">
            <p className="text-gray-600">Chargement...</p>
          </div>
        ) : lessons.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-600">Aucun cours pour le moment</p>
          </div>
        ) : (
          <div className="space-y-4">
            {lessons.map((lesson) => (
              <div
                key={lesson.id}
                className="border rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold text-lg">{lesson.subject}</h3>
                      {getStatusBadge(lesson.status)}
                    </div>
                    
                    <div className="space-y-1 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>
                          {format(new Date(lesson.start_at), "EEEE d MMMM yyyy 'à' HH:mm", { locale: fr })}
                        </span>
                      </div>
                      
                      {role === 'student' && lesson.teacher_name && (
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span>Professeur : {lesson.teacher_name}</span>
                        </div>
                      )}
                      
                      {role === 'teacher' && lesson.student_name && (
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span>Élève : {lesson.student_name}</span>
                        </div>
                      )}
                    </div>

                    {lesson.meeting_link && lesson.status === 'confirmed' && (
                      <a
                        href={lesson.meeting_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 mt-3 text-[#1F2A74] hover:underline"
                      >
                        <Video className="w-4 h-4" />
                        <span className="font-medium">Rejoindre le cours</span>
                      </a>
                    )}
                  </div>

                  {role === 'teacher' && lesson.status === 'requested' && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-green-600 border-green-600 hover:bg-green-50"
                        onClick={() => handleConfirm(lesson.id)}
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Confirmer
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-600 border-red-600 hover:bg-red-50"
                        onClick={() => handleCancel(lesson.id)}
                      >
                        <XCircle className="w-4 h-4 mr-1" />
                        Refuser
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default LessonsList;
