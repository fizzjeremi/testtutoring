import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";

interface Teacher {
  id: string;
  subjects: string[];
  user_id: string;
}

interface TeacherProfile {
  first_name: string;
}

const LessonRequestDialog = () => {
  const [open, setOpen] = useState(false);
  const [teachers, setTeachers] = useState<(Teacher & { profile?: TeacherProfile })[]>([]);
  const [selectedTeacher, setSelectedTeacher] = useState("");
  const [subject, setSubject] = useState("");
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [duration, setDuration] = useState("60");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      loadTeachers();
    }
  }, [open]);

  const loadTeachers = async () => {
    try {
      const { data: teachersData, error: teachersError } = await supabase
        .from('teachers')
        .select('id, subjects, user_id');

      if (teachersError) throw teachersError;

      // Load profiles separately
      if (teachersData && teachersData.length > 0) {
        const userIds = teachersData.map(t => t.user_id);
        const { data: profilesData } = await supabase
          .from('user_profiles')
          .select('user_id, first_name')
          .in('user_id', userIds);

        const teachersWithProfiles = teachersData.map(teacher => ({
          ...teacher,
          profile: profilesData?.find(p => p.user_id === teacher.user_id),
        }));

        setTeachers(teachersWithProfiles);
      }
    } catch (error) {
      console.error('Error loading teachers:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedTeacher || !subject || !date || !startTime) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Non authentifié");

      // Get student ID
      const { data: studentData } = await supabase
        .from('students')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!studentData) throw new Error("Profil élève non trouvé");

      // Calculate end time
      const startDateTime = new Date(`${date}T${startTime}`);
      const endDateTime = new Date(startDateTime.getTime() + parseInt(duration) * 60000);

      // Create lesson request
      const { error } = await supabase
        .from('lessons')
        .insert({
          student_id: studentData.id,
          teacher_id: selectedTeacher,
          subject,
          start_at: startDateTime.toISOString(),
          end_at: endDateTime.toISOString(),
          status: 'requested',
          notes_student: notes,
        });

      if (error) throw error;

      toast({
        title: "Demande envoyée",
        description: "Votre demande de cours a été envoyée au professeur",
      });

      setOpen(false);
      resetForm();
    } catch (error) {
      console.error('Error creating lesson request:', error);
      toast({
        title: "Erreur",
        description: "Impossible de créer la demande de cours",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setSelectedTeacher("");
    setSubject("");
    setDate("");
    setStartTime("");
    setDuration("60");
    setNotes("");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-[#1F2A74] hover:bg-[#1F2A74]/90">
          <Plus className="w-4 h-4 mr-2" />
          Demander un cours
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Demander un cours</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="teacher">Professeur *</Label>
            <Select value={selectedTeacher} onValueChange={setSelectedTeacher}>
              <SelectTrigger>
                <SelectValue placeholder="Choisir un professeur" />
              </SelectTrigger>
              <SelectContent>
                {teachers.map((teacher) => (
                  <SelectItem key={teacher.id} value={teacher.id}>
                    {teacher.profile?.first_name || 'Professeur'} - {teacher.subjects.join(', ')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="subject">Matière *</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Ex: Mathématiques, Français..."
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                required
              />
            </div>
            <div>
              <Label htmlFor="time">Heure *</Label>
              <Input
                id="time"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="duration">Durée</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="60">1 heure</SelectItem>
                <SelectItem value="90">1h30</SelectItem>
                <SelectItem value="120">2 heures</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="notes">Notes (optionnel)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Points particuliers à aborder..."
              rows={3}
            />
          </div>

          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Annuler
            </Button>
            <Button type="submit" disabled={loading} className="bg-[#1F2A74]">
              {loading ? "Envoi..." : "Envoyer la demande"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default LessonRequestDialog;
