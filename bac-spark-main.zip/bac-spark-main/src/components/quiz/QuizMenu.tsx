import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const QuizMenu = () => {
  const [theme, setTheme] = useState("");
  const navigate = useNavigate();

  const suggestedThemes = [
    "Le romantisme",
    "Le réalisme",
    "Le symbolisme",
    "Les figures de style",
    "Le théâtre classique",
    "La poésie moderne"
  ];

  const handleStart = () => {
    if (theme.trim()) {
      navigate(`/revision/quiz/session?theme=${encodeURIComponent(theme)}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      <div className="container mx-auto py-8 px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/revision")}
          className="mb-4 border-2 border-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>

        <Card className="max-w-2xl mx-auto border-2 border-gray-900">
          <CardContent className="p-6">
            <h2 className="text-2xl font-black text-gray-900 mb-6">Choisir un thème de quiz</h2>
            
            <div className="space-y-6">
              <div>
                <Label htmlFor="theme">Thème personnalisé</Label>
                <Input
                  id="theme"
                  placeholder="Ex: Les fleurs du mal de Baudelaire"
                  value={theme}
                  onChange={(e) => setTheme(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleStart()}
                />
              </div>

              <div>
                <Label>Ou choisis un thème suggéré</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {suggestedThemes.map((suggestedTheme) => (
                    <Button
                      key={suggestedTheme}
                      variant="outline"
                      onClick={() => setTheme(suggestedTheme)}
                      className={`border-2 ${theme === suggestedTheme ? 'border-orange-400 bg-orange-50' : 'border-gray-900'}`}
                    >
                      {suggestedTheme}
                    </Button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleStart}
                disabled={!theme.trim()}
                className="w-full bg-gray-900 hover:bg-gray-800 font-bold"
              >
                Commencer le quiz
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QuizMenu;
