import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Trophy, RotateCcw } from "lucide-react";

const QuizResult = () => {
  const [searchParams] = useSearchParams();
  const score = parseInt(searchParams.get('score') || '0');
  const total = parseInt(searchParams.get('total') || '0');
  const theme = searchParams.get('theme') || '';
  const navigate = useNavigate();

  const percentage = Math.round((score / total) * 100);

  const getMessage = () => {
    if (percentage >= 80) return "Excellent travail ! 🎉";
    if (percentage >= 60) return "Bien joué ! 👍";
    if (percentage >= 40) return "Pas mal, continue comme ça ! 💪";
    return "Continue à réviser, tu vas y arriver ! 📚";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      <div className="container mx-auto py-8 px-4">
        <Card className="max-w-md mx-auto border-2 border-gray-900">
          <CardContent className="p-8 text-center">
            <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
            
            <h2 className="text-3xl font-black text-gray-900 mb-2">
              Quiz terminé !
            </h2>
            
            <p className="text-gray-600 mb-6">Thème: {theme}</p>

            <div className="bg-white rounded-lg p-6 border-2 border-gray-900 mb-6">
              <div className="text-5xl font-black text-gray-900 mb-2">
                {score}/{total}
              </div>
              <div className="text-2xl font-bold text-gray-600">
                {percentage}%
              </div>
            </div>

            <p className="text-lg font-bold text-gray-900 mb-6">
              {getMessage()}
            </p>

            <div className="space-y-3">
              <Button
                onClick={() => navigate("/revision/quiz")}
                className="w-full bg-gray-900 hover:bg-gray-800 font-bold"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Nouveau quiz
              </Button>
              <Button
                onClick={() => navigate("/revision")}
                variant="outline"
                className="w-full border-2 border-gray-900"
              >
                Retour à la révision
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QuizResult;
