import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";

interface Question {
  question: string;
  options: string[];
  correct: string;
}

const QuizSession = () => {
  const [searchParams] = useSearchParams();
  const theme = searchParams.get('theme') || '';
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    generateQuiz();
  }, []);

  const generateQuiz = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-quiz', {
        body: { theme, questionsCount: 8 }
      });

      if (error) throw error;

      setQuestions(data.questions);
      toast({
        title: "Quiz généré",
        description: `${data.questions.length} questions sur "${theme}"`,
      });
    } catch (error: any) {
      console.error('Error generating quiz:', error);
      toast({
        title: "Erreur",
        description: "Impossible de générer le quiz. Réessayez.",
        variant: "destructive",
      });
      navigate("/revision/quiz");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswer = (answer: string) => {
    if (selectedAnswer !== null) return;

    setSelectedAnswer(answer);
    setShowResult(true);

    if (answer === questions[currentIndex].correct) {
      setCorrectAnswers(correctAnswers + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      saveResults();
      navigate(`/revision/quiz/results?score=${correctAnswers + (selectedAnswer === questions[currentIndex].correct ? 1 : 0)}&total=${questions.length}&theme=${encodeURIComponent(theme)}`);
    }
  };

  const saveResults = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const finalScore = correctAnswers + (selectedAnswer === questions[currentIndex].correct ? 1 : 0);

      await supabase.from('user_quiz_results').insert({
        user_id: user.id,
        theme,
        score: Math.round((finalScore / questions.length) * 100),
        questions_total: questions.length,
        correct_answers: finalScore
      });
    } catch (error) {
      console.error('Error saving results:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center">
        <p className="text-gray-600">Génération du quiz...</p>
      </div>
    );
  }

  const progress = questions.length > 0 ? ((currentIndex + 1) / questions.length) * 100 : 0;
  const currentQuestion = questions[currentIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      <div className="container mx-auto py-8 px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/revision/quiz")}
          className="mb-4 border-2 border-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>

        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-bold text-gray-600">
                Question {currentIndex + 1} / {questions.length}
              </span>
              <span className="text-sm font-bold text-gray-600">
                Score: {correctAnswers}/{questions.length}
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <Card className="border-2 border-gray-900 mb-6">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-6">
                {currentQuestion?.question}
              </h3>

              <div className="space-y-3">
                {currentQuestion?.options.map((option, index) => {
                  const isSelected = selectedAnswer === option;
                  const isCorrect = option === currentQuestion.correct;
                  const showCorrect = showResult && isCorrect;
                  const showIncorrect = showResult && isSelected && !isCorrect;

                  return (
                    <Button
                      key={index}
                      onClick={() => handleAnswer(option)}
                      disabled={showResult}
                      className={`w-full justify-start text-left h-auto p-4 ${
                        showCorrect
                          ? 'bg-green-600 hover:bg-green-700 text-white border-green-700'
                          : showIncorrect
                          ? 'bg-red-600 hover:bg-red-700 text-white border-red-700'
                          : 'bg-white hover:bg-gray-50 text-gray-900'
                      } border-2 border-gray-900`}
                      variant={isSelected ? "default" : "outline"}
                    >
                      {option}
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {showResult && (
            <Button
              onClick={handleNext}
              className="w-full bg-gray-900 hover:bg-gray-800 font-bold"
            >
              {currentIndex < questions.length - 1 ? "Question suivante" : "Voir les résultats"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuizSession;
