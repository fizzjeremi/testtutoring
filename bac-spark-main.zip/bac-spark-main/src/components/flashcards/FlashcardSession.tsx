import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Check, X } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Flashcard {
  question: string;
  answer: string;
}

const FlashcardSession = () => {
  const [theme, setTheme] = useState("");
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [mastered, setMastered] = useState(0);
  const [toReview, setToReview] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [sessionStarted, setSessionStarted] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const startSession = async () => {
    if (!theme.trim()) {
      toast({
        title: "Thème requis",
        description: "Veuillez entrer un thème pour générer les flashcards.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase.functions.invoke('generate-flashcards', {
        body: { theme, userId: user.id }
      });

      if (error) throw error;

      setFlashcards(data.flashcards);
      setSessionStarted(true);
      toast({
        title: "Flashcards générées",
        description: `${data.flashcards.length} cartes créées pour le thème "${theme}"`,
      });
    } catch (error: any) {
      console.error('Error generating flashcards:', error);
      toast({
        title: "Erreur",
        description: "Impossible de générer les flashcards. Réessayez.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKnow = () => {
    setMastered(mastered + 1);
    nextCard();
  };

  const handleDontKnow = () => {
    setToReview(toReview + 1);
    nextCard();
  };

  const nextCard = () => {
    setShowAnswer(false);
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const progress = flashcards.length > 0 ? ((currentIndex + 1) / flashcards.length) * 100 : 0;
  const currentCard = flashcards[currentIndex];
  const isLastCard = currentIndex === flashcards.length - 1;

  if (!sessionStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
        <div className="container mx-auto py-8 px-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/revision/flashcards")}
            className="mb-4 border-2 border-gray-900"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>

          <Card className="max-w-md mx-auto border-2 border-gray-900">
            <CardContent className="p-6">
              <h2 className="text-2xl font-black text-gray-900 mb-6">Choisir un thème</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="theme">Thème de révision</Label>
                  <Input
                    id="theme"
                    placeholder="Ex: Le romantisme, Les figures de style..."
                    value={theme}
                    onChange={(e) => setTheme(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && startSession()}
                  />
                </div>
                <Button
                  onClick={startSession}
                  disabled={isLoading}
                  className="w-full bg-gray-900 hover:bg-gray-800 font-bold"
                >
                  {isLoading ? "Génération..." : "Générer les flashcards"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (isLastCard && showAnswer) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
        <div className="container mx-auto py-8 px-4">
          <Card className="max-w-md mx-auto border-2 border-gray-900">
            <CardContent className="p-8 text-center">
              <h2 className="text-3xl font-black text-gray-900 mb-4">Session terminée !</h2>
              <div className="space-y-4 mb-6">
                <div className="flex items-center justify-center gap-2">
                  <Check className="w-6 h-6 text-green-600" />
                  <span className="text-xl font-bold">{mastered} maîtrisées</span>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <X className="w-6 h-6 text-red-600" />
                  <span className="text-xl font-bold">{toReview} à revoir</span>
                </div>
              </div>
              <Button
                onClick={() => navigate("/revision/flashcards")}
                className="w-full bg-gray-900 hover:bg-gray-800 font-bold"
              >
                Retour au menu
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
      <div className="container mx-auto py-8 px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/revision/flashcards")}
          className="mb-4 border-2 border-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>

        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-bold text-gray-600">
                Carte {currentIndex + 1} / {flashcards.length}
              </span>
              <span className="text-sm font-bold text-gray-600">
                Thème: {theme}
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <Card className="border-2 border-gray-900 mb-6">
            <CardContent className="p-8">
              <div className="min-h-[200px] flex flex-col justify-center">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {currentCard?.question}
                </h3>
                {showAnswer && (
                  <div className="mt-4 p-4 bg-yellow-100 rounded-lg border-2 border-gray-900">
                    <p className="text-gray-900">{currentCard?.answer}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {!showAnswer ? (
            <Button
              onClick={() => setShowAnswer(true)}
              className="w-full bg-gray-900 hover:bg-gray-800 font-bold"
            >
              Voir la réponse
            </Button>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <Button
                onClick={handleDontKnow}
                variant="outline"
                className="border-2 border-red-600 text-red-600 hover:bg-red-50 font-bold"
              >
                <X className="w-5 h-5 mr-2" />
                À revoir
              </Button>
              <Button
                onClick={handleKnow}
                className="bg-green-600 hover:bg-green-700 text-white font-bold"
              >
                <Check className="w-5 h-5 mr-2" />
                Je sais
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FlashcardSession;
