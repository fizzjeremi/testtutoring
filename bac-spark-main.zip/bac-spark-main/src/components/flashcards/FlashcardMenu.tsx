import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Zap, Plus, BookMarked } from "lucide-react";
import { useNavigate } from "react-router-dom";

const FlashcardMenu = () => {
  const navigate = useNavigate();

  const options = [
    {
      id: "reviser",
      title: "Réviser avec l'IA",
      description: "L'IA génère des flashcards sur un thème de ton choix",
      icon: Zap,
      color: "from-amber-100 to-yellow-100",
      iconBg: "bg-amber-400",
      iconColor: "text-amber-900",
      path: "/revision/flashcards/session"
    },
    {
      id: "creer",
      title: "Créer mes flashcards",
      description: "Crée tes propres cartes personnalisées",
      icon: Plus,
      color: "from-yellow-100 to-amber-100",
      iconBg: "bg-yellow-400",
      iconColor: "text-yellow-900",
      path: "/revision/flashcards/create"
    },
    {
      id: "mes-cartes",
      title: "Mes flashcards",
      description: "Révise tes cartes enregistrées",
      icon: BookMarked,
      color: "from-orange-100 to-yellow-100",
      iconBg: "bg-orange-400",
      iconColor: "text-orange-900",
      path: "/revision/flashcards/my-cards"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-gray-900 mb-2">Flashcards</h1>
          <p className="text-gray-600">Révision rapide et mémorisation efficace</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {options.map((option) => {
            const Icon = option.icon;
            return (
              <Card
                key={option.id}
                className="border-2 border-gray-900 hover:shadow-xl transition-all cursor-pointer"
                onClick={() => navigate(option.path)}
              >
                <CardContent className={`p-6 bg-gradient-to-br ${option.color}`}>
                  <div className={`w-12 h-12 ${option.iconBg} rounded-2xl flex items-center justify-center mb-4`}>
                    <Icon className={`w-6 h-6 ${option.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-black text-gray-900 mb-2">{option.title}</h3>
                  <p className="text-gray-700 text-sm mb-6">{option.description}</p>
                  <Button className="w-full bg-gray-900 hover:bg-gray-800 font-bold">
                    Commencer
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FlashcardMenu;
