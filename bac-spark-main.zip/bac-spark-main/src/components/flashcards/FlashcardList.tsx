import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Flashcard {
  id: string;
  theme: string;
  question: string;
  answer: string;
  created_at: string;
}

const FlashcardList = () => {
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [groupedCards, setGroupedCards] = useState<Record<string, Flashcard[]>>({});
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadFlashcards();
  }, []);

  const loadFlashcards = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from('user_flashcards')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setFlashcards(data || []);
      
      // Group by theme
      const grouped = (data || []).reduce((acc, card) => {
        if (!acc[card.theme]) {
          acc[card.theme] = [];
        }
        acc[card.theme].push(card);
        return acc;
      }, {} as Record<string, Flashcard[]>);
      
      setGroupedCards(grouped);
    } catch (error: any) {
      console.error('Error loading flashcards:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger tes flashcards.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('user_flashcards')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Flashcard supprimée",
        description: "La carte a été supprimée avec succès.",
      });

      loadFlashcards();
    } catch (error: any) {
      console.error('Error deleting flashcard:', error);
      toast({
        title: "Erreur",
        description: "Impossible de supprimer la flashcard.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 flex items-center justify-center">
        <p className="text-gray-600">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
      <div className="container mx-auto py-8 px-4">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/revision/flashcards")}
            className="border-2 border-gray-900"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-black text-gray-900">Mes Flashcards</h1>
            <p className="text-gray-600">{flashcards.length} carte(s) au total</p>
          </div>
        </div>

        {flashcards.length === 0 ? (
          <Card className="border-2 border-gray-900">
            <CardContent className="p-8 text-center">
              <p className="text-gray-600 mb-4">Tu n'as pas encore créé de flashcards.</p>
              <Button
                onClick={() => navigate("/revision/flashcards/create")}
                className="bg-gray-900 hover:bg-gray-800 font-bold"
              >
                Créer ma première carte
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedCards).map(([theme, cards]) => (
              <div key={theme}>
                <h2 className="text-xl font-black text-gray-900 mb-3">{theme}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {cards.map((card) => (
                    <Card key={card.id} className="border-2 border-gray-900">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-bold text-gray-900">{card.question}</h3>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(card.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <p className="text-sm text-gray-600">{card.answer}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FlashcardList;
