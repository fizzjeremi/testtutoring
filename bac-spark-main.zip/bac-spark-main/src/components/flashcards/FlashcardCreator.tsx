import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const FlashcardCreator = () => {
  const [theme, setTheme] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSave = async () => {
    if (!theme.trim() || !question.trim() || !answer.trim()) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir tous les champs.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error } = await supabase
        .from('user_flashcards')
        .insert({
          user_id: user.id,
          theme,
          question,
          answer
        });

      if (error) throw error;

      toast({
        title: "Flashcard créée",
        description: "Ta carte a été enregistrée avec succès.",
      });

      // Reset form
      setQuestion("");
      setAnswer("");
    } catch (error: any) {
      console.error('Error saving flashcard:', error);
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder la flashcard.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
      <div className="container mx-auto py-8 px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/revision/flashcards")}
          className="mb-4 border-2 border-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>

        <Card className="max-w-2xl mx-auto border-2 border-gray-900">
          <CardContent className="p-6">
            <h2 className="text-2xl font-black text-gray-900 mb-6">Créer une flashcard</h2>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="theme">Thème / Dossier</Label>
                <Input
                  id="theme"
                  placeholder="Ex: Romantisme, Figures de style..."
                  value={theme}
                  onChange={(e) => setTheme(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="question">Question</Label>
                <Input
                  id="question"
                  placeholder="Ex: Qu'est-ce qu'une métaphore ?"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="answer">Réponse</Label>
                <Textarea
                  id="answer"
                  placeholder="Écris la réponse à ta question..."
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  rows={6}
                />
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleSave}
                  disabled={isLoading}
                  className="flex-1 bg-gray-900 hover:bg-gray-800 font-bold"
                >
                  {isLoading ? "Enregistrement..." : "Enregistrer"}
                </Button>
                <Button
                  onClick={() => navigate("/revision/flashcards/my-cards")}
                  variant="outline"
                  className="border-2 border-gray-900"
                >
                  Voir mes cartes
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FlashcardCreator;
