import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MessageCircle, BookOpen, HelpCircle } from "lucide-react";

interface AideTabProps {
  contactForm: {
    name: string;
    email: string;
    level: string;
    subject: string;
    message: string;
  };
  setContactForm: (form: any) => void;
  handleContactSubmit: (e: React.FormEvent) => void;
  isSubmitting: boolean;
}

const AideTab = ({ contactForm, setContactForm, handleContactSubmit, isSubmitting }: AideTabProps) => {
  return (
    <div className="space-y-6">
      {/* Introduction */}
      <Card className="border-2 border-gray-900 bg-gradient-to-br from-blue-50 to-violet-50">
        <CardContent className="pt-6">
          <h2 className="text-2xl font-black text-gray-900 mb-3">
            Besoin d'aide ou de soutien ?
          </h2>
          <p className="text-gray-700 mb-4">
            Notre équipe Tutoring London est disponible pour accompagner les élèves et les parents 
            dans l'utilisation de BacFrançais ou pour organiser un suivi personnalisé.
          </p>
          <div className="bg-white border-2 border-[#1F2A74] rounded-2xl p-4 mt-4">
            <p className="text-sm text-gray-700">
              <strong>Tutoring London International</strong> accompagne chaque année des centaines d'élèves 
              dans la préparation du Bac et des examens internationaux. Notre mission : offrir un soutien 
              individualisé, en ligne ou en présentiel, adapté à chaque profil d'apprentissage.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Option 1 : Contacter un professeur */}
        <Card className="border-2 border-gray-900">
          <CardHeader>
            <div className="w-12 h-12 bg-violet-400 rounded-2xl flex items-center justify-center mb-4">
              <MessageCircle className="w-6 h-6 text-violet-900" />
            </div>
            <CardTitle>Contacter un professeur</CardTitle>
            <CardDescription>
              Être mis en relation avec un tuteur qualifié
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleContactSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Prénom / Nom</Label>
                <Input
                  id="name"
                  value={contactForm.name}
                  onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                  required
                  className="border-2 border-gray-900"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={contactForm.email}
                  onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                  required
                  className="border-2 border-gray-900"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="level">Niveau scolaire</Label>
                <Select
                  value={contactForm.level}
                  onValueChange={(value) => setContactForm({ ...contactForm, level: value })}
                >
                  <SelectTrigger className="border-2 border-gray-900">
                    <SelectValue placeholder="Sélectionne ton niveau" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3e">3ème</SelectItem>
                    <SelectItem value="2nde">2nde</SelectItem>
                    <SelectItem value="1re">1ère</SelectItem>
                    <SelectItem value="term">Terminale</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Matière concernée</Label>
                <Input
                  id="subject"
                  value={contactForm.subject}
                  onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                  placeholder="Ex: Français, Littérature..."
                  className="border-2 border-gray-900"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={contactForm.message}
                  onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                  required
                  rows={4}
                  className="border-2 border-gray-900"
                  placeholder="Décris ton besoin..."
                />
              </div>

              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-[#1F2A74] hover:bg-[#1a2260] font-bold"
              >
                {isSubmitting ? "Envoi en cours..." : "Envoyer la demande"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Option 2 : Support technique */}
        <Card className="border-2 border-gray-900">
          <CardHeader>
            <div className="w-12 h-12 bg-orange-400 rounded-2xl flex items-center justify-center mb-4">
              <HelpCircle className="w-6 h-6 text-orange-900" />
            </div>
            <CardTitle>Support technique BacFrançais</CardTitle>
            <CardDescription>
              Signaler un problème ou poser une question
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Un bug ? Une question sur l'utilisation de la plateforme ?
            </p>
            <Button 
              variant="outline"
              className="w-full border-2 border-gray-900 font-bold"
              asChild
            >
              <a href="mailto:support@tutoringlondon.co.uk">
                Contacter le support
              </a>
            </Button>
          </CardContent>
        </Card>

        {/* Option 3 : Centre de ressources */}
        <Card className="border-2 border-gray-900">
          <CardHeader>
            <div className="w-12 h-12 bg-cyan-400 rounded-2xl flex items-center justify-center mb-4">
              <BookOpen className="w-6 h-6 text-cyan-900" />
            </div>
            <CardTitle>Centre de ressources</CardTitle>
            <CardDescription>
              Guides et conseils pour réussir
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="ghost"
              className="w-full justify-start text-left hover:bg-gray-50"
              asChild
            >
              <a 
                href="https://www.tutoringlondon.co.uk/en" 
                target="_blank"
                rel="noopener noreferrer"
              >
                FAQ Bac Français →
              </a>
            </Button>
            <Button 
              variant="ghost"
              className="w-full justify-start text-left hover:bg-gray-50"
              asChild
            >
              <a 
                href="https://www.tutoringlondon.co.uk/en" 
                target="_blank"
                rel="noopener noreferrer"
              >
                Guides méthodologiques →
              </a>
            </Button>
            <Button 
              variant="ghost"
              className="w-full justify-start text-left hover:bg-gray-50"
              asChild
            >
              <a 
                href="https://www.tutoringlondon.co.uk/en" 
                target="_blank"
                rel="noopener noreferrer"
              >
                Conseils de préparation →
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AideTab;
