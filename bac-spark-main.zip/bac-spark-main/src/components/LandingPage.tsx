import { Button } from "@/components/ui/button";
import { Flame, Sparkles, Award, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b-2 border-gray-200 bg-background">
        <div className="mx-auto max-w-7xl px-6 py-4 flex items-center justify-between">
          <div className="text-2xl font-black">
            <span className="text-[#1F2A74]">Tutoring</span>
            <span className="text-gray-900">London</span>
          </div>
          <Button 
            onClick={() => navigate("/login")}
            variant="default" 
            className="bg-gray-900 text-white rounded-full px-6 py-2 font-bold hover:bg-gray-700"
          >
            Connexion
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="mx-auto max-w-7xl px-6 py-16 md:py-24">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Column */}
          <div className="space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-blue-100 rounded-full px-4 py-2">
              <Flame className="w-5 h-5 text-[#1F2A74]" />
              <span className="font-semibold text-[#1F2A74]">Excellence académique depuis 2015</span>
            </div>

            {/* H1 with Glow Effect */}
            <div className="space-y-2">
              <h1 className="text-6xl font-black leading-tight text-gray-900">
                Tutorat d'excellence
                <br />
                pour votre
              </h1>
              <div className="relative inline-block">
                <div className="absolute inset-0 bg-[#1F2A74] blur-2xl opacity-20 rounded-2xl"></div>
                <h1 className="text-6xl font-black leading-tight text-[#1F2A74] relative">
                  réussite
                </h1>
              </div>
            </div>

            {/* Subtitle */}
            <p className="text-xl text-gray-600 mb-10">
              Cours particuliers avec des professeurs qualifiés.
              <br />
              Module Bac Français intégré. Plateforme tout-en-un.
            </p>

            {/* CTAs */}
            <div className="flex gap-4">
              <Button 
                onClick={() => navigate("/signup")}
                className="bg-gray-900 text-white rounded-2xl px-6 py-6 font-bold hover:bg-gray-800 shadow-xl"
              >
                Commencer gratuitement
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                variant="outline" 
                className="border-2 border-gray-900 bg-white text-gray-900 rounded-2xl px-6 py-6 font-bold hover:bg-gray-50"
              >
                Voir comment ça marche
              </Button>
            </div>

            {/* Mini Stats */}
            <div className="flex gap-8 pt-4">
              <div>
                <div className="text-3xl font-black text-[#1F2A74]">500+</div>
                <div className="text-sm text-gray-600">Élèves</div>
              </div>
              <div>
                <div className="text-3xl font-black text-[#1F2A74]">50+</div>
                <div className="text-sm text-gray-600">Professeurs</div>
              </div>
              <div>
                <div className="text-3xl font-black text-[#1F2A74]">98%</div>
                <div className="text-sm text-gray-600">Satisfaction</div>
              </div>
            </div>
          </div>

          {/* Right Column - Feature Card */}
          <div className="hidden md:block relative">
            <div className="bg-gradient-to-br from-[#1F2A74] to-[#4A5899] rounded-3xl p-8 text-white shadow-2xl transform rotate-2 hover:rotate-0 transition-transform relative overflow-hidden">
              {/* Content */}
              <div className="space-y-6 relative z-10">
                <h3 className="text-2xl font-black">Cours en ligne personnalisés</h3>
                
                <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 border-2 border-white/30">
                  <p className="font-bold mb-2">✓ Professeurs qualifiés</p>
                  <p className="text-sm opacity-90">Sélectionnés pour leur expertise et pédagogie</p>
                </div>

                <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 border-2 border-white/30">
                  <p className="font-bold mb-2">📅 Planning flexible</p>
                  <p className="text-sm opacity-90">Réservez vos cours selon vos disponibilités</p>
                </div>

                <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 border-2 border-white/30">
                  <p className="font-bold mb-2">🎓 Module Bac Français</p>
                  <p className="text-sm opacity-90">Accès illimité 24/7 avec coach IA</p>
                </div>
              </div>

              {/* Floating Icons */}
              <div className="absolute top-4 right-20 bg-white w-12 h-12 rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles className="w-6 h-6 text-[#1F2A74]" />
              </div>
              <div className="absolute bottom-4 left-4 bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg">
                <Award className="w-6 h-6 text-[#1F2A74]" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="bg-gray-50 py-16 border-t-2 border-gray-200">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="text-3xl font-black text-gray-900 text-center mb-12">
            Ce que disent nos élèves
          </h2>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-2xl border-2 border-gray-200 hover:border-[#1F2A74] p-6 transition-all shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-[#1F2A74] flex items-center justify-center text-white font-black text-xl">
                  E
                </div>
                <div>
                  <div className="font-black text-gray-900">Emma L.</div>
                  <div className="text-sm text-gray-600">Terminale, Lycée français</div>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                "Ma professeure est exceptionnelle ! J'ai progressé énormément en maths grâce à un suivi personnalisé."
              </p>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-2xl border-2 border-gray-200 hover:border-[#1F2A74] p-6 transition-all shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-[#1F2A74] flex items-center justify-center text-white font-black text-xl">
                  L
                </div>
                <div>
                  <div className="font-black text-gray-900">Lucas M.</div>
                  <div className="text-sm text-gray-600">Première, Bac Français</div>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                "Le module Bac Français avec le coach IA est génial. Je peux m'entraîner à toute heure !"
              </p>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-2xl border-2 border-gray-200 hover:border-[#1F2A74] p-6 transition-all shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-[#1F2A74] flex items-center justify-center text-white font-black text-xl">
                  C
                </div>
                <div>
                  <div className="font-black text-gray-900">Clara D.</div>
                  <div className="text-sm text-gray-600">Seconde, Sciences</div>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                "La plateforme est super intuitive. J'aime pouvoir réserver mes cours en quelques clics."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t-2 border-gray-200 py-8">
        <div className="mx-auto max-w-7xl px-6 text-center text-sm text-gray-600">
          <p>© 2025 Tutoring London. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
