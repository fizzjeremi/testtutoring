import { Link } from "react-router-dom";
import tutoringLogo from "@/assets/tutoring-london-logo.png";

const Footer = () => {
  return (
    <footer className="bg-[#F8F9FB] border-t border-gray-200 mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Bloc 1 : Identité */}
          <div>
            <img 
              src={tutoringLogo} 
              alt="Tutoring London International" 
              className="h-16 mb-4"
            />
            <h3 className="font-bold text-gray-900 mb-2">
              BacFrançais by Tutoring London International
            </h3>
            <p className="text-sm text-[#444444] mb-2">
              © 2025 – Tous droits réservés
            </p>
            <p className="text-sm text-[#444444] mb-4">
              Un programme éducatif développé par Tutoring London, organisme d'enseignement 
              international spécialisé dans l'accompagnement des élèves français et anglophones.
            </p>
            <a 
              href="https://www.tutoringlondon.co.uk/en" 
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#1F2A74] hover:underline font-medium"
            >
              Site Tutoring London →
            </a>
          </div>

          {/* Bloc 2 : Navigation rapide */}
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Navigation rapide</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/bibliotheque" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Bibliothèque
                </Link>
              </li>
              <li>
                <Link to="/progres" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Progrès
                </Link>
              </li>
              <li>
                <Link to="/cartes-mentales" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Carte mentale
                </Link>
              </li>
              <li>
                <Link to="/revision" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Révision
                </Link>
              </li>
              <li>
                <Link to="/profil" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Profil
                </Link>
              </li>
              <li>
                <Link to="/profil?tab=aide" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Aide & Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Bloc 3 : Informations */}
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Informations</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/mentions-legales" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Mentions légales
                </Link>
              </li>
              <li>
                <Link to="/politique-confidentialite" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Politique de confidentialité
                </Link>
              </li>
              <li>
                <Link to="/conditions-utilisation" className="text-[#444444] hover:text-[#1F2A74] transition-colors">
                  Conditions d'utilisation
                </Link>
              </li>
              <li>
                <a 
                  href="mailto:contact@tutoringlondon.co.uk" 
                  className="text-[#444444] hover:text-[#1F2A74] transition-colors"
                >
                  Contact : contact@tutoringlondon.co.uk
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
