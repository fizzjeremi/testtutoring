import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Download, Edit } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";

interface Fiche {
  id: string;
  titre: string;
  contenu: string;
  tags: string[];
  created_at: string;
  updated_at: string;
}

const FicheViewer = () => {
  const { id } = useParams();
  const [fiche, setFiche] = useState<Fiche | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadFiche();
  }, [id]);

  const loadFiche = async () => {
    try {
      const { data, error } = await supabase
        .from('user_fiches')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      setFiche(data);
    } catch (error: any) {
      console.error('Error loading fiche:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger la fiche.",
        variant: "destructive",
      });
      navigate("/revision/fiches");
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportPDF = () => {
    if (!fiche) return;

    // Simple text export (PDF generation would require additional library)
    const text = `${fiche.titre}\n\n${fiche.contenu}\n\nTags: ${fiche.tags?.join(', ')}`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fiche.titre}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Export réussi",
      description: "Ta fiche a été exportée.",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-amber-50 flex items-center justify-center">
        <p className="text-gray-600">Chargement...</p>
      </div>
    );
  }

  if (!fiche) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-amber-50">
      <div className="container mx-auto py-8 px-4">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/revision/fiches")}
            className="border-2 border-gray-900"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-black text-gray-900">{fiche.titre}</h1>
          </div>
          <Button
            onClick={() => navigate(`/revision/fiches/edit/${id}`)}
            variant="outline"
            className="border-2 border-gray-900"
          >
            <Edit className="w-4 h-4 mr-2" />
            Modifier
          </Button>
          <Button
            onClick={handleExportPDF}
            className="bg-gray-900 hover:bg-gray-800 font-bold"
          >
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </Button>
        </div>

        <Card className="max-w-4xl mx-auto border-2 border-gray-900">
          <CardContent className="p-8">
            {fiche.tags && fiche.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {fiche.tags.map((tag, index) => (
                  <Badge key={index} variant="outline">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}

            <div className="prose max-w-none">
              <pre className="whitespace-pre-wrap font-sans text-gray-900">
                {fiche.contenu}
              </pre>
            </div>

            <div className="mt-8 text-sm text-gray-500 border-t pt-4">
              <p>Créée le {new Date(fiche.created_at).toLocaleDateString('fr-FR')}</p>
              <p>Modifiée le {new Date(fiche.updated_at).toLocaleDateString('fr-FR')}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FicheViewer;
