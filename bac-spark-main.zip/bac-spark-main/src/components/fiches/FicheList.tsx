import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus, Trash2, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Fiche {
  id: string;
  titre: string;
  contenu: string;
  tags: string[];
  created_at: string;
}

const FicheList = () => {
  const [fiches, setFiches] = useState<Fiche[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadFiches();
  }, []);

  const loadFiches = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from('user_fiches')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setFiches(data || []);
    } catch (error: any) {
      console.error('Error loading fiches:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger tes fiches.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('user_fiches')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Fiche supprimée",
        description: "La fiche a été supprimée avec succès.",
      });

      loadFiches();
    } catch (error: any) {
      console.error('Error deleting fiche:', error);
      toast({
        title: "Erreur",
        description: "Impossible de supprimer la fiche.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-amber-50 flex items-center justify-center">
        <p className="text-gray-600">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-amber-50">
      <div className="container mx-auto py-8 px-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/revision")}
              className="border-2 border-gray-900"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-black text-gray-900">Mes Fiches</h1>
              <p className="text-gray-600">{fiches.length} fiche(s)</p>
            </div>
          </div>
          <Button
            onClick={() => navigate("/revision/fiches/create")}
            className="bg-gray-900 hover:bg-gray-800 font-bold"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nouvelle fiche
          </Button>
        </div>

        {fiches.length === 0 ? (
          <Card className="border-2 border-gray-900">
            <CardContent className="p-8 text-center">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Tu n'as pas encore créé de fiches.</p>
              <Button
                onClick={() => navigate("/revision/fiches/create")}
                className="bg-gray-900 hover:bg-gray-800 font-bold"
              >
                Créer ma première fiche
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {fiches.map((fiche) => (
              <Card
                key={fiche.id}
                className="border-2 border-gray-900 cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => navigate(`/revision/fiches/${fiche.id}`)}
              >
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-black text-gray-900 text-lg">{fiche.titre}</h3>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(fiche.id);
                      }}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                    {fiche.contenu}
                  </p>
                  {fiche.tags && fiche.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {fiche.tags.map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FicheList;
