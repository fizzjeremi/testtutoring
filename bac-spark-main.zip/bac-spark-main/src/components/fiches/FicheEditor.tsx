import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Save } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";

const FicheEditor = () => {
  const { id } = useParams();
  const [titre, setTitre] = useState("");
  const [contenu, setContenu] = useState("");
  const [tags, setTags] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const isEditing = !!id;

  useEffect(() => {
    if (id) {
      loadFiche();
    }
  }, [id]);

  const loadFiche = async () => {
    try {
      const { data, error } = await supabase
        .from('user_fiches')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;

      setTitre(data.titre);
      setContenu(data.contenu);
      setTags(data.tags?.join(', ') || '');
    } catch (error: any) {
      console.error('Error loading fiche:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger la fiche.",
        variant: "destructive",
      });
      navigate("/revision/fiches");
    }
  };

  const handleSave = async () => {
    if (!titre.trim() || !contenu.trim()) {
      toast({
        title: "Champs requis",
        description: "Le titre et le contenu sont obligatoires.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const tagsArray = tags.split(',').map(t => t.trim()).filter(t => t);

      if (isEditing) {
        const { error } = await supabase
          .from('user_fiches')
          .update({
            titre,
            contenu,
            tags: tagsArray
          })
          .eq('id', id);

        if (error) throw error;

        toast({
          title: "Fiche mise à jour",
          description: "Tes modifications ont été enregistrées.",
        });
      } else {
        const { error } = await supabase
          .from('user_fiches')
          .insert({
            user_id: user.id,
            titre,
            contenu,
            tags: tagsArray
          });

        if (error) throw error;

        toast({
          title: "Fiche créée",
          description: "Ta fiche a été enregistrée avec succès.",
        });
      }

      navigate("/revision/fiches");
    } catch (error: any) {
      console.error('Error saving fiche:', error);
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder la fiche.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-amber-50">
      <div className="container mx-auto py-8 px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/revision/fiches")}
          className="mb-4 border-2 border-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>

        <Card className="max-w-4xl mx-auto border-2 border-gray-900">
          <CardContent className="p-6">
            <h2 className="text-2xl font-black text-gray-900 mb-6">
              {isEditing ? "Modifier la fiche" : "Créer une fiche"}
            </h2>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="titre">Titre</Label>
                <Input
                  id="titre"
                  placeholder="Ex: Les figures de style dans Les Fleurs du Mal"
                  value={titre}
                  onChange={(e) => setTitre(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="tags">Tags (séparés par des virgules)</Label>
                <Input
                  id="tags"
                  placeholder="Ex: Baudelaire, Poésie, Figures de style"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="contenu">Contenu</Label>
                <Textarea
                  id="contenu"
                  placeholder="Écris le contenu de ta fiche de révision..."
                  value={contenu}
                  onChange={(e) => setContenu(e.target.value)}
                  rows={15}
                  className="font-mono"
                />
              </div>

              <Button
                onClick={handleSave}
                disabled={isLoading}
                className="w-full bg-gray-900 hover:bg-gray-800 font-bold"
              >
                <Save className="w-4 h-4 mr-2" />
                {isLoading ? "Enregistrement..." : "Enregistrer"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FicheEditor;
