import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import Onboarding from "./pages/Onboarding";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Lessons from "./pages/Lessons";
import Availabilities from "./pages/Availabilities";
import Invoices from "./pages/Invoices";
import Users from "./pages/admin/Users";
import AdminLessons from "./pages/admin/AdminLessons";
import Settings from "./pages/admin/Settings";
import Library from "./pages/Library";
import ResourceDetail from "./pages/ResourceDetail";
import Progres from "./pages/Progres";
import CarteMentale from "./pages/CarteMentale";
import MindMapsList from "./pages/MindMapsList";
import Profile from "./pages/Profile";
import TutoringProfile from "./pages/TutoringProfile";
import Revision from "./pages/Revision";
import NotFound from "./pages/NotFound";
import MentionsLegales from "./pages/MentionsLegales";
import PolitiqueConfidentialite from "./pages/PolitiqueConfidentialite";
import ConditionsUtilisation from "./pages/ConditionsUtilisation";
import FlashcardMenu from "./components/flashcards/FlashcardMenu";
import FlashcardSession from "./components/flashcards/FlashcardSession";
import FlashcardCreator from "./components/flashcards/FlashcardCreator";
import FlashcardList from "./components/flashcards/FlashcardList";
import QuizMenu from "./components/quiz/QuizMenu";
import QuizSession from "./components/quiz/QuizSession";
import QuizResult from "./components/quiz/QuizResult";
import FicheList from "./components/fiches/FicheList";
import FicheEditor from "./components/fiches/FicheEditor";
import FicheViewer from "./components/fiches/FicheViewer";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/profile" element={<TutoringProfile />} />
          <Route path="/lessons" element={<Lessons />} />
          <Route path="/availabilities" element={<Availabilities />} />
          <Route path="/invoices" element={<Invoices />} />
          <Route path="/admin/users" element={<Users />} />
          <Route path="/admin/lessons" element={<AdminLessons />} />
          <Route path="/admin/settings" element={<Settings />} />
          <Route path="/bibliotheque" element={<Library />} />
          <Route path="/ressources/:id" element={<ResourceDetail />} />
          <Route path="/progres" element={<Progres />} />
          <Route path="/cartes-mentales" element={<MindMapsList />} />
          <Route path="/carte-mentale/:id" element={<CarteMentale />} />
          <Route path="/revision" element={<Revision />} />
          <Route path="/bac" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/profil" element={<Profile />} />
          <Route path="/mentions-legales" element={<MentionsLegales />} />
          <Route path="/politique-confidentialite" element={<PolitiqueConfidentialite />} />
          <Route path="/conditions-utilisation" element={<ConditionsUtilisation />} />
          <Route path="/revision/flashcards" element={<FlashcardMenu />} />
          <Route path="/revision/flashcards/session" element={<FlashcardSession />} />
          <Route path="/revision/flashcards/create" element={<FlashcardCreator />} />
          <Route path="/revision/flashcards/my-cards" element={<FlashcardList />} />
          <Route path="/revision/quiz" element={<QuizMenu />} />
          <Route path="/revision/quiz/session" element={<QuizSession />} />
          <Route path="/revision/quiz/results" element={<QuizResult />} />
          <Route path="/revision/fiches" element={<FicheList />} />
          <Route path="/revision/fiches/create" element={<FicheEditor />} />
          <Route path="/revision/fiches/edit/:id" element={<FicheEditor />} />
          <Route path="/revision/fiches/:id" element={<FicheViewer />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
